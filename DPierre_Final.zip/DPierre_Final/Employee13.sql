
--**************************************  EXECUTE Employee record 11 STORE PROCEDURES **************************************

--SET IDENTITY_INSERT Employee ON
EXEC dbo.EmployeeRecord10 13, '08/30/2001', 'Lomanc', 'Lao', '128 Lex st', 'Mac Ville', 'Nevada', 34332;

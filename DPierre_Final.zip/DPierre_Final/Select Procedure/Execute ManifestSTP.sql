--************************************** EXECUTE ManifestSTP STORED PROCEDURE**************************************

EXEC ManifestSTP 12, 12, 'Bevrage', 'Sugar Bag', 536, 111, 11
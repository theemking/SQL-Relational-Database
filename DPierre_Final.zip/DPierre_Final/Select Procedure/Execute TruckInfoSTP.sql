
EXEC TruckInfoSTP2 12, 11, 'Long Feeder', 'Class B', '17 Feet Trailor', '12 Speed', 'Gasonile', 5332, 'Fair'

--************************************** EXECUTE HaulRecordSTP STORED PROCEDURE**************************************

EXEC HaulRecordSTP 11, 'Judge', 'Rex', 'BoxRox', '2007-07-12', '2007-07-12', 8834, Repaired, 11

USE Truck

EXEC [dbo].[EmployeeHaulReport] 12, 'Sorrsut', 'Oiy', '2009-02-12', 1, 'International', 'Expo', '2020-01-10', '2020-02-11'--, 3456


--************************************** EXECUTE EmployeeSTP STORED PROCEDURE**************************************

EXEC EmployeeSTP 12,	'2001-08-21', 'Luc', 'Polo', '53 Lex st', 'Mark Township',	'Origon',	34332
--************************************** EXECUTE DriverSTP STORED PROCEDURE**************************************

EXEC DriverSTP 13, 11, '2001-09-20', 1
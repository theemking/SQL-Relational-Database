--************************************** EXECUTE MaintnanceSTP STORED PROCEDURE**************************************

EXEC MaintnanceSTP 12, 11, '2020-02-15', '2020-02-16', 'Replace winshield', 384
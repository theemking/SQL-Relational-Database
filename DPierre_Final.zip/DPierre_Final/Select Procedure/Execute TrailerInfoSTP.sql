--************************************** EXECUTE TrailerInfoSTP STORED PROCEDURE**************************************

EXEC TrailerInfoSTP 11, 'Wide side', '11 tones', 54335, 'Half Flat', 11

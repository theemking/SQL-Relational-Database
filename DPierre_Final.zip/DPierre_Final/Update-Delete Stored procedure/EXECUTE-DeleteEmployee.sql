--**************************************  DELETE EMPLOYEE STORE PROCEDURES **************************************

EXECUTE DeleteEmployee 15

SELECT * FROM Employee
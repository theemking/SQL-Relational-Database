--************************************** EXECUTE DELETE DRIVER STORE PROCEDURES **************************************

EXECUTE DeleteDriver 15

SELECT * FROM Driver
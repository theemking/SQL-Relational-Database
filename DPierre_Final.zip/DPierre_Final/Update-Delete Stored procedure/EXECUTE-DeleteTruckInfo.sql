--************************************** EXECUTE DELETE TruckInfo STORE PROCEDURES **************************************

EXECUTE DeleteTruckInfo 13

SELECT * FROM TruckInfo
--**************************************  EXECUTE DELETE Maintnance STORE PROCEDURES **************************************


EXEC DeleteMaintnance 14

select * from Maintnance
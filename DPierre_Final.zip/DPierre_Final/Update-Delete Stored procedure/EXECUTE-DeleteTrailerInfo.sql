--************************************** EXECUTE DELETE TrailerInfo STORE PROCEDURES **************************************


EXECUTE DeleteTrailerInfo 14

SELECT * FROM TrailerInfo
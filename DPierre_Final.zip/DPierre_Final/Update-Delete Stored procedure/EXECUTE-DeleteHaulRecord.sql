--************************************** EXECUTE DELETE HaulRecord STORE PROCEDURES **************************************

EXECUTE DeleteHaulRecord 13

SELECT * FROM HaulRecord
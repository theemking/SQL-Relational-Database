
--**************************************  DELETE Manifest STORE PROCEDURES **************************************

EXECUTE DeleteManifest 13

SELECT * FROM Manifest
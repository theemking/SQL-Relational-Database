select * from HaulRecord

select AVG(MileageCount)
FROM HaulRecord